<?php
	//Informations de connexion à la base de données
	define('DB_TYPE', 'mysql');
    define('DB_HOST', 'host.docker.internal');
    define('DB_NAME', 'bd_livredor');
    define('DB_USER', 'root');
    define('DB_PASS', 'emf123');
?>